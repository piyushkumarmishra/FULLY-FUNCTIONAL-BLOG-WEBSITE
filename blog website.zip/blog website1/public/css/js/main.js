const quotes = [
  "“Arise, awake, and stop not till the goal is reached.” — Swami Vivekananda",
  "“Take risks in your life. If you win, you can lead. If you lose, you can guide.” — Swami Vivekananda",
  "“Talk to yourself at least once in a day.” — Swami Vivekananda",
  "“You have to grow from the inside out.” — Swami Vivekananda",
  "“Believe you can and you're halfway there.” — Theodore Roosevelt"
];

let qIndex = 0;

window.onload = () => {
  const box = document.getElementById("quoteBox");
  if (!box) return;

  box.innerText = quotes[0];

  setInterval(() => {
    qIndex = (qIndex + 1) % quotes.length;
    box.innerText = quotes[qIndex];
  }, 5000);
};

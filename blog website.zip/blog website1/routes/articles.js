const express = require("express");
const router = express.Router();
const Article = require("../models/article");
const Comment = require("../models/comment");

// New article
router.get("/new", (req, res) => {
  res.render("articles/new", { article: new Article() });
});

// Edit article
router.get("/edit/:id", async (req, res) => {
  const article = await Article.findById(req.params.id);
  res.render("articles/edit", { article });
});

// Show article
router.get("/:slug", async (req, res) => {
  const article = await Article.findOne({ slug: req.params.slug });
  const comments = await Comment.find({ articleId: article._id }).sort({ createdAt: -1 });
  res.render("articles/show", { article, comments });
});

// Like comment
router.post("/comment/:id/like", async (req, res) => {
  const c = await Comment.findById(req.params.id);
  c.likes++;
  await c.save();
  res.redirect("back");
});

// Dislike comment
router.post("/comment/:id/dislike", async (req, res) => {
  const c = await Comment.findById(req.params.id);
  c.dislikes++;
  await c.save();
  res.redirect("back");
});

// Create comment
router.post("/:id/comment", async (req, res) => {
  await Comment.create({
    articleId: req.params.id,
    name: req.body.name,
    body: req.body.body
  });
  res.redirect("back");
});

// Create article
router.post("/", async (req, res) => {
  let article = new Article(req.body);
  try {
    article = await article.save();
    res.redirect(`/articles/${article.slug}`);
  } catch {
    res.render("articles/new", { article });
  }
});

// Update
router.put("/:id", async (req, res) => {
  let article = await Article.findById(req.params.id);
  article.title = req.body.title;
  article.description = req.body.description;
  article.markdown = req.body.markdown;

  try {
    article = await article.save();
    res.redirect(`/articles/${article.slug}`);
  } catch {
    res.render("articles/edit", { article });
  }
});

// Delete
router.delete("/:id", async (req, res) => {
  await Article.findByIdAndDelete(req.params.id);
  res.redirect("/");
});

module.exports = router;

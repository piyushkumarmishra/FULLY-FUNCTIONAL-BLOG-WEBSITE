const express = require("express");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const Article = require("./models/article");
const articleRouter = require("./routes/articles");

const app = express();

mongoose.connect("mongodb://127.0.0.1:27017/blogwebsite");

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(methodOverride("_method"));
app.use(express.static("public"));

app.get("/", async (req, res) => {
  const articles = await Article.find().sort({ createdAt: "desc" });
  res.render("index", { articles });
});

app.get("/about", (req, res) => res.render("about"));
app.get("/contact", (req, res) => res.render("contact"));

app.use("/articles", articleRouter);

app.listen(8000, () => console.log("Server running on 8000"));
